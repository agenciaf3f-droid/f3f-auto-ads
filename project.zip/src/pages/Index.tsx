import PublishForm from "@/components/PublishForm";
import Header from "@/components/Header";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold mb-1">
            Publicar <span className="text-gradient">Anúncio</span>
          </h1>
          <p className="text-sm text-muted-foreground">
            Configure e publique seu anúncio no Meta Ads em poucos passos
          </p>
        </div>
        <PublishForm />
      </main>
    </div>
  );
};

export default Index;
