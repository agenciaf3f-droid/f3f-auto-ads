import { useState, useEffect } from "react";
import Header from "@/components/Header";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { fetchMetaStatus } from "@/lib/meta-api";

export default function SettingsPage() {
  const [metaStatus, setMetaStatus] = useState<{ connected: boolean; meta_name?: string; expires_at?: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetaStatus()
      .then(setMetaStatus)
      .catch(() => setMetaStatus({ connected: false }))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <h1 className="font-display text-2xl font-bold mb-6">Configurações</h1>

        <Card className="glass-card p-6 space-y-4">
          <Label className="font-display font-semibold text-sm">Conexão Meta</Label>
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <div className="flex items-center gap-2">
              {metaStatus?.connected ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-success" />
                  <div>
                    <span className="text-sm">Conectado</span>
                    {metaStatus.meta_name && <p className="text-xs text-muted-foreground">{metaStatus.meta_name}</p>}
                    {metaStatus.expires_at && (
                      <p className="text-xs text-muted-foreground">
                        Expira: {new Date(metaStatus.expires_at).toLocaleDateString("pt-BR")}
                      </p>
                    )}
                  </div>
                </>
              ) : (
                <>
                  <XCircle className="w-5 h-5 text-destructive" />
                  <span className="text-sm">Desconectado</span>
                </>
              )}
            </div>
          )}
        </Card>
      </main>
    </div>
  );
}
