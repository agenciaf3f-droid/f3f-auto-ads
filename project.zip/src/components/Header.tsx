import { Link, useLocation } from "react-router-dom";
import { Zap, Settings, LogOut, User, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";

export default function Header() {
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="border-b border-border/50 bg-card/80 backdrop-blur-xl sticky top-0 z-50">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center glow-primary">
            <Zap className="w-4 h-4 text-primary" />
          </div>
          <span className="font-display font-bold text-lg">
            F3F <span className="text-gradient">AUTO-ADS</span>
          </span>
        </Link>
        <div className="flex items-center gap-2">
          <nav className="flex gap-1">
            <Link to="/">
              <Button variant={location.pathname === "/" ? "secondary" : "ghost"} size="sm" className="text-xs">
                Publicar
              </Button>
            </Link>
            <Link to="/settings">
              <Button variant={location.pathname === "/settings" ? "secondary" : "ghost"} size="sm" className="text-xs gap-1">
                <Settings className="w-3.5 h-3.5" />
                Config
              </Button>
            </Link>
          </nav>

          <Button variant="ghost" size="sm" onClick={toggleTheme} className="h-8 w-8 p-0">
            {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </Button>

          {user && (
            <div className="flex items-center gap-2 pl-2 border-l border-border/50">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <User className="w-3.5 h-3.5" />
                <span className="max-w-[120px] truncate hidden sm:inline">{user.email}</span>
              </div>
              <Button variant="ghost" size="sm" onClick={signOut} className="h-7 w-7 p-0">
                <LogOut className="w-3.5 h-3.5" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
