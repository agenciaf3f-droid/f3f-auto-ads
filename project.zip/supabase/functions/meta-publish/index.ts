import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface StepLog {
  step: string;
  status: "start" | "success" | "error";
  ts: string;
  detail?: string;
}

function ts() { return new Date().toISOString(); }

function sanitizePayload(obj: Record<string, any>): Record<string, any> {
  const clean = { ...obj };
  delete clean.access_token;
  delete clean.app_secret;
  return clean;
}

function formatMetaError(err: any) {
  return {
    error_message: err?.message || "Erro desconhecido",
    error_code: err?.code || null,
    error_subcode: err?.error_subcode || null,
    error_user_msg: err?.error_user_msg || "",
    error_user_title: err?.error_user_title || "",
    raw_error: err || null,
  };
}

function cleanTargeting(t: Record<string, any>): Record<string, any> {
  const clean = { ...t };
  delete clean.targeting_optimization;
  delete clean.brand_safety_content_filter_levels;
  return clean;
}

function buildTargeting(audienceType: string, audienceId: string, targetingSpec: any, locationTargeting?: { included?: any[]; excluded?: any[] }) {
  let base: Record<string, any>;
  if (audienceType === "saved" && targetingSpec) {
    base = cleanTargeting({ ...targetingSpec });
  } else {
    base = {
      custom_audiences: [{ id: audienceId }],
      geo_locations: { countries: ["BR"] },
    };
  }
  if (locationTargeting?.included && locationTargeting.included.length > 0) {
    const geo: Record<string, any> = {};
    const countries: string[] = [];
    const regions: { key: string }[] = [];
    const cities: { key: string }[] = [];
    for (const loc of locationTargeting.included) {
      if (loc.type === "country") countries.push(loc.country_code || loc.key);
      else if (loc.type === "region") regions.push({ key: loc.key });
      else if (loc.type === "city") cities.push({ key: loc.key });
      else regions.push({ key: loc.key });
    }
    if (countries.length) geo.countries = countries;
    if (regions.length) geo.regions = regions;
    if (cities.length) geo.cities = cities;
    base.geo_locations = geo;

    if (locationTargeting.excluded && locationTargeting.excluded.length > 0) {
      const exCountries: string[] = [];
      const exRegions: { key: string }[] = [];
      const exCities: { key: string }[] = [];
      for (const loc of locationTargeting.excluded) {
        if (loc.type === "country") exCountries.push(loc.country_code || loc.key);
        else if (loc.type === "region") exRegions.push({ key: loc.key });
        else if (loc.type === "city") exCities.push({ key: loc.key });
        else exRegions.push({ key: loc.key });
      }
      const exGeo: Record<string, any> = {};
      if (exCountries.length) exGeo.countries = exCountries;
      if (exRegions.length) exGeo.regions = exRegions;
      if (exCities.length) exGeo.cities = exCities;
      base.excluded_geo_locations = exGeo;
    }
  }
  return base;
}

// =====================================================================
//  INSTAGRAM MEDIA RESOLUTION (shared by FASE 1 and FASE 3)
// =====================================================================

async function resolveInstagramMediaId(
  accessToken: string,
  adAccountId: string,
  igLink: string,
  knownPageId?: string,
  knownIgActorId?: string,
  logs: StepLog[] = [],
): Promise<{
  instagram_media_id?: string;
  ig_account_id?: string;
  page_id?: string;
  shortcode?: string;
  media_permalink?: string;
  error?: string;
}> {
  const normalizeUrl = (value?: string) => (value || "").trim().toLowerCase().split("?")[0].replace(/\/+$/, "");

  const normalizedLink = normalizeUrl(igLink);
  console.log(`[ig_input] normalized_link=${normalizedLink}`);

  const match = normalizedLink.match(/instagram\.com\/(?:.*\/)?(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/);
  if (!match) {
    const err = "Link inválido: shortcode não encontrado (formatos suportados: /p/, /reel/, /reels/, /tv/).";
    logs.push({ step: "ig_input", status: "error", ts: ts(), detail: err });
    return { error: err };
  }

  const shortcode = match[2];
  console.log(`[ig_input] type=${match[1]}, shortcode=${shortcode}`);
  logs.push({ step: "ig_input", status: "success", ts: ts(), detail: `type=${match[1]}, shortcode=${shortcode}` });

  const resolveMediaFromIgActor = async (
    igActorId: string,
    pageId?: string,
  ): Promise<{ mediaId?: string; permalink?: string; pageId?: string; igActorId?: string; error?: string }> => {
    const endpoint = `https://graph.facebook.com/v21.0/${igActorId}/media?fields=id,shortcode,permalink&limit=30`;
    const res = await fetch(`${endpoint}&access_token=${accessToken}`);
    const data = await res.json();

    if (data.error) {
      logs.push({ step: "ig_media_resolve", status: "error", ts: ts(), detail: `ig_actor=${igActorId}, code=${data.error.code}, msg=${data.error.message}` });
      return { error: `Falha ao resolver mídia do IG: ${data.error.message}` };
    }

    const found = (data.data || []).find((m: any) => m.shortcode === shortcode || normalizeUrl(m.permalink).includes(shortcode.toLowerCase()));
    if (!found) return {};

    console.log(`[ig_media_resolve] FOUND media_id=${found.id}, ig_actor=${igActorId}`);
    logs.push({ step: "ig_media_resolve", status: "success", ts: ts(), detail: `media_id=${found.id}, ig_actor=${igActorId}` });
    return { mediaId: found.id, permalink: found.permalink, pageId, igActorId };
  };

  let resolvedMedia: { mediaId?: string; permalink?: string; pageId?: string; igActorId?: string; error?: string } = {};

  if (knownIgActorId) {
    resolvedMedia = await resolveMediaFromIgActor(knownIgActorId, knownPageId);
    if (resolvedMedia.error) return { error: resolvedMedia.error };
  }

  if (!resolvedMedia.mediaId && !knownIgActorId) {
    let pagesUrl: string | null = `https://graph.facebook.com/v21.0/me/accounts?fields=id,name,instagram_business_account{id}&limit=25&access_token=${accessToken}`;
    while (pagesUrl && !resolvedMedia.mediaId) {
      const pagesRes = await fetch(pagesUrl);
      const pagesData = await pagesRes.json();
      if (pagesData.error) {
        logs.push({ step: "ig_media_resolve", status: "error", ts: ts(), detail: pagesData.error.message });
        return { error: `Falha ao listar páginas: ${pagesData.error.message}` };
      }
      for (const page of pagesData.data || []) {
        if (!page.instagram_business_account?.id) continue;
        const hit = await resolveMediaFromIgActor(page.instagram_business_account.id, page.id);
        if (hit.error) return { error: hit.error };
        if (hit.mediaId) { resolvedMedia = hit; break; }
      }
      pagesUrl = pagesData.paging?.next || null;
    }
  } else if (!resolvedMedia.mediaId && knownIgActorId) {
    const err = `media_id não encontrado para shortcode=${shortcode} na conta IG ${knownIgActorId}.`;
    logs.push({ step: "ig_media_resolve", status: "error", ts: ts(), detail: err });
    return { error: err };
  }

  if (!resolvedMedia.mediaId) {
    const err = `media_id não encontrado para shortcode=${shortcode}.`;
    logs.push({ step: "ig_media_resolve", status: "error", ts: ts(), detail: err });
    return { error: err };
  }

  return {
    instagram_media_id: resolvedMedia.mediaId,
    ig_account_id: resolvedMedia.igActorId || knownIgActorId,
    page_id: resolvedMedia.pageId || knownPageId,
    shortcode,
    media_permalink: resolvedMedia.permalink,
  };
}

// =====================================================================
//  DRIVE UPLOAD (shared)
// =====================================================================

async function uploadDriveCreative(
  accessToken: string,
  adAccountId: string,
  driveLink: string
): Promise<{ image_hash?: string; video_id?: string; error?: string }> {
  let downloadUrl = driveLink;
  const fileIdMatch = driveLink.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (fileIdMatch) downloadUrl = `https://drive.google.com/uc?export=download&id=${fileIdMatch[1]}`;
  const fileRes = await fetch(downloadUrl, { redirect: "follow" });
  if (!fileRes.ok) return { error: "Falha ao baixar arquivo do Drive." };
  const contentType = fileRes.headers.get("content-type") || "";
  const fileBlob = await fileRes.blob();
  const isVideo = contentType.includes("video");
  if (isVideo) {
    const formData = new FormData();
    formData.append("access_token", accessToken);
    formData.append("file_url", downloadUrl);
    const uploadRes = await fetch(`https://graph.facebook.com/v21.0/${adAccountId}/advideos`, { method: "POST", body: formData });
    const uploadData = await uploadRes.json();
    if (uploadData.error) return { error: uploadData.error.message };
    return { video_id: uploadData.id };
  } else {
    const formData = new FormData();
    formData.append("access_token", accessToken);
    formData.append("filename", "creative.jpg");
    formData.append("bytes", await blobToBase64(fileBlob));
    const uploadRes = await fetch(`https://graph.facebook.com/v21.0/${adAccountId}/adimages`, { method: "POST", body: formData });
    const uploadData = await uploadRes.json();
    if (uploadData.error) return { error: uploadData.error.message };
    const images = uploadData.images;
    if (images) {
      const firstKey = Object.keys(images)[0];
      return { image_hash: images[firstKey].hash };
    }
    return { error: "Falha ao obter hash da imagem." };
  }
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => { resolve((reader.result as string).split(",")[1]); };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function resolvePageAndIg(accessToken: string, adAccountId?: string): Promise<{ pageId?: string; igActorId?: string; error?: string }> {
  async function getAllPages(): Promise<any[]> {
    const allPages: any[] = [];
    let url: string | null = `https://graph.facebook.com/v21.0/me/accounts?fields=id,name,instagram_business_account{id}&limit=25&access_token=${accessToken}`;
    while (url) {
      const res = await fetch(url);
      const data = await res.json();
      if (data.data) allPages.push(...data.data);
      url = data.paging?.next || null;
      if (allPages.length >= 300) break;
    }
    return allPages;
  }

  if (adAccountId) {
    try {
      const igRes = await fetch(`https://graph.facebook.com/v21.0/${adAccountId}/instagram_accounts?fields=id,username&limit=25&access_token=${accessToken}`);
      const igData = await igRes.json();
      if (igData.data && igData.data.length > 0) {
        const igActorId = igData.data[0].id;
        const allPages = await getAllPages();
        let pageId: string | undefined;
        for (const page of allPages) {
          if (page.instagram_business_account?.id === igActorId) { pageId = page.id; break; }
        }
        if (!pageId && allPages.length > 0) pageId = allPages[0].id;
        return { pageId, igActorId };
      }
    } catch (e) {
      console.log(`[publish] resolvePageAndIg failed: ${e.message}`);
    }
  }

  const allPages = await getAllPages();
  if (allPages.length === 0) return { error: "Nenhuma página encontrada." };
  const pageId = allPages[0].id;
  let igActorId: string | undefined;
  for (const page of allPages) {
    if (page.instagram_business_account?.id) { igActorId = page.instagram_business_account.id; break; }
  }
  return { pageId, igActorId };
}

// =====================================================================
//  FASE 1 CREATIVE BUILDER — Instagram Profile Traffic
// =====================================================================

async function buildFase1Creative(
  accessToken: string,
  adAccountId: string,
  creativeLink: string,
  creativeType: string,
  creativeName: string,
  pageId: string,
  igActorId: string | undefined,
  igUsername: string | undefined,
  logs: StepLog[],
): Promise<{ spec?: Record<string, any>; error?: string }> {
  const igProfileLink = igUsername ? `https://www.instagram.com/${igUsername}/` : `https://www.instagram.com/`;
  const isIgLink = creativeType === "instagram" || (!creativeType && creativeLink?.includes("instagram.com"));
  const isDriveLink = creativeType === "drive" || (!creativeType && (creativeLink?.includes("drive.google.com") || creativeLink?.includes("docs.google.com")));

  console.log(`[FASE1-creative] type=${creativeType}, isIg=${isIgLink}, isDrive=${isDriveLink}`);

  if (isIgLink) {
    const result = await resolveInstagramMediaId(accessToken, adAccountId, creativeLink, pageId, igActorId, logs);
    if (result.error) return { error: result.error };
    if (!result.instagram_media_id) return { error: "instagram_media_id não resolvido." };

    const resolvedIgActor = result.ig_account_id || igActorId;
    if (!resolvedIgActor) return { error: "instagram_user_id não disponível." };

    const spec: Record<string, any> = {
      source_instagram_media_id: result.instagram_media_id,
      instagram_user_id: resolvedIgActor,
      call_to_action: { type: "VISIT_PROFILE", value: { link: igProfileLink } },
    };

    console.log(`[FASE1-creative] OK: media=${result.instagram_media_id}, ig=${resolvedIgActor}, CTA=VISIT_PROFILE`);
    logs.push({ step: "fase1_creative", status: "success", ts: ts(), detail: `media=${result.instagram_media_id}, CTA=VISIT_PROFILE` });
    return { spec };

  } else if (isDriveLink) {
    const result = await uploadDriveCreative(accessToken, adAccountId, creativeLink);
    if (result.error) return { error: result.error };

    if (result.image_hash) {
      const linkData: Record<string, any> = {
        image_hash: result.image_hash,
        message: creativeName,
        link: igProfileLink,
        call_to_action: { type: "VISIT_PROFILE", value: { link: igProfileLink } },
      };
      const storySpec: Record<string, any> = { page_id: pageId, link_data: linkData };
      if (igActorId) storySpec.instagram_user_id = igActorId;
      console.log(`[FASE1-creative] OK: image_hash, CTA=VISIT_PROFILE, link=${igProfileLink}`);
      logs.push({ step: "fase1_creative", status: "success", ts: ts(), detail: `image_hash=${result.image_hash}, CTA=VISIT_PROFILE` });
      return { spec: { object_story_spec: storySpec } };

    } else if (result.video_id) {
      // Wait for video processing and get thumbnail
      let thumbnailField: Record<string, string> = {};
      for (let attempt = 0; attempt < 12; attempt++) {
        await new Promise(r => setTimeout(r, 5000));
        const vidRes = await fetch(`https://graph.facebook.com/v21.0/${result.video_id}?fields=status,picture&access_token=${accessToken}`);
        const vidData = await vidRes.json();
        if (vidData.picture) {
          try {
            const thumbRes = await fetch(vidData.picture);
            if (thumbRes.ok) {
              const thumbBlob = await thumbRes.blob();
              const thumbB64 = await blobToBase64(thumbBlob);
              const imgForm = new FormData();
              imgForm.append("access_token", accessToken);
              imgForm.append("filename", "video_thumb.jpg");
              imgForm.append("bytes", thumbB64);
              const imgUpRes = await fetch(`https://graph.facebook.com/v21.0/${adAccountId}/adimages`, { method: "POST", body: imgForm });
              const imgUpData = await imgUpRes.json();
              if (imgUpData.images) { const firstKey = Object.keys(imgUpData.images)[0]; thumbnailField = { image_hash: imgUpData.images[firstKey].hash }; }
            }
          } catch {}
          if (!thumbnailField.image_hash) thumbnailField = { image_url: vidData.picture };
          break;
        }
      }

      const videoData: Record<string, any> = {
        video_id: result.video_id,
        ...thumbnailField,
        message: creativeName,
        call_to_action: { type: "VISIT_PROFILE", value: { link: igProfileLink } },
      };
      const storySpec: Record<string, any> = { page_id: pageId, video_data: videoData };
      if (igActorId) storySpec.instagram_user_id = igActorId;
      console.log(`[FASE1-creative] OK: video_id=${result.video_id}, CTA=VISIT_PROFILE`);
      logs.push({ step: "fase1_creative", status: "success", ts: ts(), detail: `video_id=${result.video_id}, CTA=VISIT_PROFILE` });
      return { spec: { object_story_spec: storySpec } };
    }
  }

  return { error: "Link inválido para FASE 1." };
}

// =====================================================================
//  FASE 3 CREATIVE BUILDER — WhatsApp Leads / Conversations
//
//  Structural reference (Ads Manager behavior):
//  - CTA: WHATSAPP_MESSAGE (fixed, never user-editable)
//  - Link: https://api.whatsapp.com/send?phone=<number>&text=<encoded_message>
//  - Message text: greeting + ready_message (from internal template system, NOT WABA)
//  - Creative source (IG post or Drive) only affects the media, NOT the CTA/link
// =====================================================================

function buildWhatsAppLink(phoneNumber: string, greetingText?: string, readyMessage?: string): string {
  const cleanPhone = phoneNumber.replace(/\D/g, "");
  let link = `https://api.whatsapp.com/send?phone=${cleanPhone}`;
  // Build pre-filled message from greeting + ready_message
  const parts: string[] = [];
  if (greetingText?.trim()) parts.push(greetingText.trim());
  if (readyMessage?.trim()) parts.push(readyMessage.trim());
  if (parts.length > 0) {
    link += `&text=${encodeURIComponent(parts.join("\n\n"))}`;
  }
  return link;
}

async function buildFase3Creative(
  accessToken: string,
  adAccountId: string,
  creativeLink: string,
  creativeType: string,
  creativeName: string,
  pageId: string,
  igActorId: string | undefined,
  whatsappPhone: string,  // display phone number for the WA link
  greetingText: string | undefined,
  readyMessage: string | undefined,
  logs: StepLog[],
): Promise<{ spec?: Record<string, any>; error?: string }> {
  // ── FIXED by preset ──
  const waLink = buildWhatsAppLink(whatsappPhone, greetingText, readyMessage);
  const callToAction = { type: "WHATSAPP_MESSAGE", value: { link: waLink } };

  console.log(`[FASE3-creative] ═══ FIXED fields ═══`);
  console.log(`[FASE3-creative] CTA: type=WHATSAPP_MESSAGE (fixed by preset)`);
  console.log(`[FASE3-creative] link: ${waLink}`);
  console.log(`[FASE3-creative] greeting: "${greetingText || ""}"`);
  console.log(`[FASE3-creative] ready_message: "${readyMessage || ""}"`);
  console.log(`[FASE3-creative] ═══ VARIABLE fields ═══`);
  console.log(`[FASE3-creative] source: ${creativeType}, name: ${creativeName}`);

  const isIgLink = creativeType === "instagram" || (!creativeType && creativeLink?.includes("instagram.com"));
  const isDriveLink = creativeType === "drive" || (!creativeType && (creativeLink?.includes("drive.google.com") || creativeLink?.includes("docs.google.com")));

  if (isIgLink) {
    // IG source: use source_instagram_media_id + call_to_action
    const result = await resolveInstagramMediaId(accessToken, adAccountId, creativeLink, pageId, igActorId, logs);
    if (result.error) return { error: result.error };
    if (!result.instagram_media_id) return { error: "instagram_media_id não resolvido." };

    const resolvedIgActor = result.ig_account_id || igActorId;
    if (!resolvedIgActor) return { error: "instagram_user_id não disponível para creative FASE 3." };

    const spec: Record<string, any> = {
      source_instagram_media_id: result.instagram_media_id,
      instagram_user_id: resolvedIgActor,
      call_to_action: callToAction,
    };

    console.log(`[FASE3-creative] OK (instagram): media=${result.instagram_media_id}, ig=${resolvedIgActor}`);
    logs.push({ step: "fase3_creative", status: "success", ts: ts(), detail: `source=instagram, media=${result.instagram_media_id}, CTA=WHATSAPP_MESSAGE` });
    return { spec };

  } else if (isDriveLink) {
    const result = await uploadDriveCreative(accessToken, adAccountId, creativeLink);
    if (result.error) return { error: result.error };

    if (result.image_hash) {
      const linkData: Record<string, any> = {
        image_hash: result.image_hash,
        message: readyMessage || creativeName,
        link: waLink,
        call_to_action: callToAction,
      };
      const storySpec: Record<string, any> = { page_id: pageId, link_data: linkData };
      if (igActorId) storySpec.instagram_user_id = igActorId;
      console.log(`[FASE3-creative] OK (drive/image): hash=${result.image_hash}`);
      logs.push({ step: "fase3_creative", status: "success", ts: ts(), detail: `source=drive/image, hash=${result.image_hash}, CTA=WHATSAPP_MESSAGE` });
      return { spec: { object_story_spec: storySpec } };

    } else if (result.video_id) {
      // Wait for thumbnail
      let thumbnailField: Record<string, string> = {};
      for (let attempt = 0; attempt < 12; attempt++) {
        await new Promise(r => setTimeout(r, 5000));
        const vidRes = await fetch(`https://graph.facebook.com/v21.0/${result.video_id}?fields=status,picture&access_token=${accessToken}`);
        const vidData = await vidRes.json();
        if (vidData.picture) {
          try {
            const thumbRes = await fetch(vidData.picture);
            if (thumbRes.ok) {
              const thumbBlob = await thumbRes.blob();
              const thumbB64 = await blobToBase64(thumbBlob);
              const imgForm = new FormData();
              imgForm.append("access_token", accessToken);
              imgForm.append("filename", "video_thumb.jpg");
              imgForm.append("bytes", thumbB64);
              const imgUpRes = await fetch(`https://graph.facebook.com/v21.0/${adAccountId}/adimages`, { method: "POST", body: imgForm });
              const imgUpData = await imgUpRes.json();
              if (imgUpData.images) { const firstKey = Object.keys(imgUpData.images)[0]; thumbnailField = { image_hash: imgUpData.images[firstKey].hash }; }
            }
          } catch {}
          if (!thumbnailField.image_hash) thumbnailField = { image_url: vidData.picture };
          break;
        }
      }

      const videoData: Record<string, any> = {
        video_id: result.video_id,
        ...thumbnailField,
        message: readyMessage || creativeName,
        call_to_action: callToAction,
      };
      const storySpec: Record<string, any> = { page_id: pageId, video_data: videoData };
      if (igActorId) storySpec.instagram_user_id = igActorId;
      console.log(`[FASE3-creative] OK (drive/video): video_id=${result.video_id}`);
      logs.push({ step: "fase3_creative", status: "success", ts: ts(), detail: `source=drive/video, video_id=${result.video_id}, CTA=WHATSAPP_MESSAGE` });
      return { spec: { object_story_spec: storySpec } };
    }
  }

  return { error: "Link inválido para FASE 3." };
}

// (diagnostic logic is now inline in tryCreateAdsetFase3)

// =====================================================================
//  MAIN HANDLER
// =====================================================================

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const logs: StepLog[] = [];
  const respond = (body: Record<string, any>, status = 200) =>
    new Response(JSON.stringify({ ...body, logs }), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  try {
    const body = await req.json();
    const {
      access_token, ad_account_id, audience_id, audience_type,
      targeting_spec, budget,
      campaign_name, adset_name, ad_name,
      existing_campaign_id,
      generated_name,
      preset,
      distribution_structure,
      creatives,
      identity,
      creative_link, creative_type, creative_name,
      whatsapp_number, whatsapp_number_id, location_targeting, cta_text, greeting_text, ready_message,
      schedule, utm_template,
    } = body;

    const structure = distribution_structure || "ABO";
    const isWhatsAppPreset = preset?.destination_type === "WHATSAPP";
    const isIgProfilePreset = preset?.destination_type === "INSTAGRAM_PROFILE";
    const fase3CampaignObjective = "OUTCOME_LEADS";

    // ══════════════════════════════════════════════════════════════════
    //  PIPELINE LOG: Identify which preset we're running
    // ══════════════════════════════════════════════════════════════════
    const presetLabel = isWhatsAppPreset ? "FASE 3" : isIgProfilePreset ? "FASE 1" : "GENERIC";
    console.log(`[publish] ═══════════════════════════════════════════`);
    console.log(`[publish] PRESET: ${presetLabel}`);
    console.log(`[publish] STRUCTURE: ${structure}`);
    console.log(`[publish] BUDGET: ${budget} (placement: ${structure === "CBO" ? "CAMPAIGN" : "ADSET"})`);
    console.log(`[publish] STATUS POLICY: campaign=PAUSED, adsets=ACTIVE, ads=ACTIVE`);

    if (isWhatsAppPreset) {
      console.log(`[publish] ── FASE 3 FIXED CONFIG ──`);
      console.log(`[publish]   objective: OUTCOME_LEADS (FIXED)`);
      console.log(`[publish]   optimization_goal: CONVERSATIONS (FIXED)`);
      console.log(`[publish]   destination_type: WHATSAPP (FIXED)`);
      console.log(`[publish]   billing_event: IMPRESSIONS (FIXED)`);
      console.log(`[publish]   bid_strategy: LOWEST_COST_WITHOUT_CAP (FIXED)`);
      console.log(`[publish]   CTA: WHATSAPP_MESSAGE (FIXED, not editable)`);
      console.log(`[publish] ── FASE 3 VARIABLE DATA ──`);
      console.log(`[publish]   whatsapp_number (display): ${whatsapp_number}`);
      console.log(`[publish]   whatsapp_number_id (internal): ${whatsapp_number_id} (type=${typeof whatsapp_number_id}, len=${String(whatsapp_number_id || "").length})`);
      console.log(`[publish]   page_id: ${identity?.page_id || "auto-resolve"}`);
      console.log(`[publish]   greeting: "${greeting_text || ""}"`);
      console.log(`[publish]   ready_message: "${ready_message || ""}"`);
      console.log(`[publish]   promoted_object: { page_id, whatsapp_phone_number } (ALWAYS both)`);
    } else if (isIgProfilePreset) {
      console.log(`[publish] ── FASE 1 FIXED CONFIG ──`);
      console.log(`[publish]   objective: OUTCOME_TRAFFIC`);
      console.log(`[publish]   optimization_goal: PROFILE_VISIT`);
      console.log(`[publish]   destination_type: INSTAGRAM_PROFILE`);
      console.log(`[publish]   CTA: VISIT_PROFILE (automatic)`);
      console.log(`[publish]   advantage_audience: DISABLED (enforced)`);
    }
    console.log(`[publish] ═══════════════════════════════════════════`);

    // Build creatives list
    const creativesList: { type: string; link: string; name: string }[] =
      creatives && creatives.length > 0
        ? creatives
        : [{ type: creative_type, link: creative_link, name: creative_name || ad_name || "Ad" }];

    // --- Resolve Page & IG ---
    let pageId: string;
    let igActorId: string | undefined;

    if (identity?.page_id) {
      pageId = identity.page_id;
      igActorId = identity.instagram_actor_id || undefined;
      logs.push({ step: "resolve_page", status: "success", ts: ts(), detail: `identity from frontend: page=${pageId}, ig=${igActorId || "none"}` });

      if (isIgProfilePreset && (!igActorId || isNaN(Number(igActorId)))) {
        const errMsg = `Instagram_actor_id inválido: '${igActorId}'.`;
        logs.push({ step: "validate_identity", status: "error", ts: ts(), detail: errMsg });
        return respond({ ok: false, step: "validate_identity", error_message: errMsg });
      }
    } else {
      logs.push({ step: "resolve_page", status: "start", ts: ts() });
      const pageInfo = await resolvePageAndIg(access_token, ad_account_id);
      if (pageInfo.error) {
        logs.push({ step: "resolve_page", status: "error", ts: ts(), detail: pageInfo.error });
        return respond({ ok: false, step: "resolve_page", error_message: pageInfo.error });
      }
      pageId = pageInfo.pageId!;
      igActorId = pageInfo.igActorId;
      logs.push({ step: "resolve_page", status: "success", ts: ts(), detail: `page=${pageId}, ig=${igActorId || "none"}` });

      if (isIgProfilePreset && (!igActorId || isNaN(Number(igActorId)))) {
        return respond({ ok: false, step: "validate_identity", error_message: `Nenhum Instagram Business válido.` });
      }
    }

    // --- Resolve ALL creatives using preset-specific builder ---
    logs.push({ step: "resolve_creatives", status: "start", ts: ts(), detail: `${creativesList.length} creative(s), builder=${presetLabel}` });
    const resolvedCreatives: { spec: Record<string, any>; name: string }[] = [];

    for (let ci = 0; ci < creativesList.length; ci++) {
      const cr = creativesList[ci];
      console.log(`[publish] creative ${ci + 1}/${creativesList.length}: type=${cr.type}, name=${cr.name}, builder=${presetLabel}`);

      let result: { spec?: Record<string, any>; error?: string };

      if (isWhatsAppPreset) {
        // ── FASE 3: dedicated builder ──
        result = await buildFase3Creative(
          access_token, ad_account_id, cr.link, cr.type, cr.name,
          pageId, igActorId,
          whatsapp_number || "",  // phone display for WA link
          greeting_text, ready_message,
          logs,
        );
      } else if (isIgProfilePreset) {
        // ── FASE 1: dedicated builder ──
        result = await buildFase1Creative(
          access_token, ad_account_id, cr.link, cr.type, cr.name,
          pageId, igActorId,
          identity?.instagram_username || undefined,
          logs,
        );
      } else {
        // ── GENERIC fallback ──
        result = await buildFase1Creative(
          access_token, ad_account_id, cr.link, cr.type, cr.name,
          pageId, igActorId,
          identity?.instagram_username || undefined,
          logs,
        );
      }

      if (result.error) {
        logs.push({ step: "resolve_creatives", status: "error", ts: ts(), detail: `creative ${ci + 1} "${cr.name}": ${result.error}` });
        return respond({ ok: false, step: "resolve_creative", error_message: result.error });
      }
      resolvedCreatives.push({ spec: result.spec!, name: cr.name });
    }
    logs.push({ step: "resolve_creatives", status: "success", ts: ts(), detail: `${resolvedCreatives.length} resolved` });

    const targeting = buildTargeting(audience_type || "custom", audience_id, targeting_spec, location_targeting);
    const finalCampaignName = campaign_name || generated_name || "Campaign";

    // ══════════════════════════════════════════════════════════════════
    //  CAMPAIGN BUILDER
    // ══════════════════════════════════════════════════════════════════
    let campaignId: string;
    if (existing_campaign_id) {
      logs.push({ step: "campaign", status: "success", ts: ts(), detail: `existing: ${existing_campaign_id}` });
      campaignId = existing_campaign_id;
    } else {
      logs.push({ step: "campaign", status: "start", ts: ts() });
      const resolvedCampaignObjective = isWhatsAppPreset ? fase3CampaignObjective : (preset?.objective || "OUTCOME_TRAFFIC");
      const campaignPayload: Record<string, any> = {
        name: finalCampaignName,
        objective: resolvedCampaignObjective,
        status: "PAUSED",
        buying_type: "AUCTION",
        special_ad_categories: [],
        is_adset_budget_sharing_enabled: false,
        access_token,
      };

      if (structure === "CBO") {
        campaignPayload.daily_budget = Math.round(Number(budget) * 100);
        console.log(`[publish] CAMPAIGN BUDGET (CBO): ${campaignPayload.daily_budget} cents`);
      }

      console.log(`[publish] campaign objective (${presetLabel}): ${resolvedCampaignObjective}`);
      console.log(`[publish] campaign payload final: ${JSON.stringify(sanitizePayload(campaignPayload))}`);

      const campaignRes = await fetch(`https://graph.facebook.com/v21.0/${ad_account_id}/campaigns`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(campaignPayload),
      });
      const campaignData = await campaignRes.json();
      console.log(`[publish] campaign response: ${JSON.stringify(campaignData)}`);
      if (campaignData.error) {
        const cErr = campaignData.error;
        console.log(`[publish] campaign error details: code=${cErr.code}, subcode=${cErr.error_subcode}, user_title=${cErr.error_user_title || "N/A"}, user_msg=${cErr.error_user_msg || "N/A"}`);
        logs.push({
          step: "campaign",
          status: "error",
          ts: ts(),
          detail: `code=${cErr.code} | subcode=${cErr.error_subcode} | user_title=${cErr.error_user_title || ""} | user_msg=${cErr.error_user_msg || ""} | response=${JSON.stringify(campaignData)}`,
        });
        return respond({ ok: false, step: "campaign", ...formatMetaError(campaignData.error) });
      }
      campaignId = campaignData.id;
      logs.push({ step: "campaign", status: "success", ts: ts(), detail: `id=${campaignId} | response=${JSON.stringify(campaignData)}` });
    }

    // ══════════════════════════════════════════════════════════════════
    //  ADSET BUILDERS — completely isolated per preset
    // ══════════════════════════════════════════════════════════════════

    // === FASE 1 AdSet builder ===
    const buildFase1Adset = (name: string): Record<string, any> => {
      const p: Record<string, any> = {
        name,
        campaign_id: campaignId,
        billing_event: "IMPRESSIONS",
        optimization_goal: "PROFILE_VISIT",
        bid_strategy: preset?.bid_strategy || "LOWEST_COST_WITHOUT_CAP",
        targeting: { ...targeting, targeting_automation: { advantage_audience: 0 } },
        status: "ACTIVE",
        destination_type: "INSTAGRAM_PROFILE",
        promoted_object: { page_id: pageId },
        access_token,
      };
      if (structure === "ABO") {
        p.daily_budget = Math.round(Number(budget) * 100);
      }
      if (schedule?.start_time) p.start_time = schedule.start_time;
      else p.start_time = new Date().toISOString();
      if (schedule?.end_time) p.end_time = schedule.end_time;

      console.log(`[FASE1-adset] ── FIXED: destination=INSTAGRAM_PROFILE, optimization=PROFILE_VISIT, advantage_audience=0`);
      console.log(`[FASE1-adset] ── VARIABLE: name="${name}", page=${pageId}, budget=${p.daily_budget || "CBO"}`);
      return p;
    };

    // === FASE 3 AdSet builder ===
    //
    // FIXED structure replicated from real working WhatsApp adset.
    // promoted_object includes BOTH whats_app_business_phone_number_id AND whatsapp_phone_number.
    //
    const buildFase3Adset = (name: string): Record<string, any> => {
      const internalId = String(whatsapp_number_id || "");
      const displayPhone = String(whatsapp_number || "");
      const cleanPhone = displayPhone.replace(/\D/g, "");

      if (!internalId) {
        console.log(`[FASE3-adset] ⚠ WARNING: whatsapp_number_id is empty — promoted_object may be invalid`);
      }

      // promoted_object: exact structure from real working adset
      const promotedObject: Record<string, any> = {
        page_id: pageId,
        smart_pse_enabled: false,
        whats_app_business_phone_number_id: internalId,
        whatsapp_phone_number: cleanPhone,
      };

      // attribution_spec: 7-day click-through (from working adset)
      const attributionSpec = [
        { event_type: "CLICK_THROUGH", window_days: 1 },
      ];

      // targeting: merge dynamic audience data with defaults from working adset
      const fase3Targeting: Record<string, any> = { ...targeting };
      if (fase3Targeting.geo_locations && !fase3Targeting.geo_locations.location_types) {
        fase3Targeting.geo_locations.location_types = ["home", "recent"];
      }
      if (!fase3Targeting.brand_safety_content_filter_levels) {
        fase3Targeting.brand_safety_content_filter_levels = ["AN_STANDARD"];
      }
      if (!fase3Targeting.targeting_automation) {
        fase3Targeting.targeting_automation = {
          advantage_audience: 1,
          individual_setting: {},
        };
      }
      if (fase3Targeting.user_age_unknown === undefined) {
        fase3Targeting.user_age_unknown = true;
      }

      const p: Record<string, any> = {
        name,
        campaign_id: campaignId,
        billing_event: "IMPRESSIONS",
        optimization_goal: "CONVERSATIONS",
        bid_strategy: "LOWEST_COST_WITHOUT_CAP",
        targeting: fase3Targeting,
        status: "ACTIVE",
        destination_type: "WHATSAPP",
        promoted_object: promotedObject,
        attribution_spec: attributionSpec,
        access_token,
      };
      if (structure === "ABO") {
        p.daily_budget = Math.round(Number(budget) * 100);
      }
      if (schedule?.start_time) p.start_time = schedule.start_time;
      else p.start_time = new Date().toISOString();
      if (schedule?.end_time) p.end_time = schedule.end_time;

      // ── MANDATORY LOGS ──
      console.log(`[FASE3-adset] ═══ ADSET BUILD (DETERMINISTIC) ═══`);
      console.log(`[FASE3-adset] billing_event: IMPRESSIONS (FIXED)`);
      console.log(`[FASE3-adset] optimization_goal: CONVERSATIONS (FIXED)`);
      console.log(`[FASE3-adset] destination_type: WHATSAPP (FIXED)`);
      console.log(`[FASE3-adset] bid_strategy: LOWEST_COST_WITHOUT_CAP (FIXED)`);
      console.log(`[FASE3-adset] promoted_object: ${JSON.stringify(promotedObject)}`);
      console.log(`[FASE3-adset]   page_id: ${pageId}`);
      console.log(`[FASE3-adset]   smart_pse_enabled: false`);
      console.log(`[FASE3-adset]   whats_app_business_phone_number_id: ${internalId}`);
      console.log(`[FASE3-adset]   whatsapp_phone_number: ${cleanPhone}`);
      console.log(`[FASE3-adset] attribution_spec: ${JSON.stringify(attributionSpec)}`);
      console.log(`[FASE3-adset] targeting (keys): ${Object.keys(fase3Targeting).join(", ")}`);
      console.log(`[FASE3-adset] budget: ${p.daily_budget || "CBO (campaign)"}`);
      console.log(`[FASE3-adset] name: "${name}"`);
      console.log(`[FASE3-adset] CTA: WHATSAPP_MESSAGE (FIXED, set at creative level)`);
      console.log(`[FASE3-adset] ═══ END ADSET BUILD ═══`);

      return p;
    };

    // Router
    const buildAdsetPayload = (name: string): Record<string, any> => {
      if (isIgProfilePreset) return buildFase1Adset(name);
      if (isWhatsAppPreset) return buildFase3Adset(name);
      // Fallback
      const p: Record<string, any> = {
        name, campaign_id: campaignId,
        billing_event: preset?.billing_event || "IMPRESSIONS",
        optimization_goal: preset?.optimization_goal || "LINK_CLICKS",
        bid_strategy: preset?.bid_strategy || "LOWEST_COST_WITHOUT_CAP",
        targeting, status: "ACTIVE", access_token,
      };
      if (structure === "ABO") p.daily_budget = Math.round(Number(budget) * 100);
      if (schedule?.start_time) p.start_time = schedule.start_time;
      else p.start_time = new Date().toISOString();
      if (schedule?.end_time) p.end_time = schedule.end_time;
      if (preset?.destination_type) p.destination_type = preset.destination_type;
      return p;
    };

    console.log(`[publish] builder selected: ${presetLabel}`);

    // ══════════════════════════════════════════════════════════════════
    //  CREATE ADSETS + CREATIVES + ADS
    // ══════════════════════════════════════════════════════════════════

    let adsetsCreated = 0;
    let adsCreated = 0;
    let creativesCreated = 0;
    const adsetIds: string[] = [];
    const adIds: string[] = [];
    const failures: { index: number; name: string; step: string; reason: string }[] = [];

    const createCreativeAndAd = async (cr: { spec: Record<string, any>; name: string }, idx: number, adsetId: string) => {
      const creativePayload: Record<string, any> = { name: `Creative - ${cr.name}`, ...cr.spec, access_token };
      if (utm_template && !isIgProfilePreset) creativePayload.url_tags = utm_template;

      logs.push({ step: `creative_${idx}`, status: "start", ts: ts(), detail: `name=${cr.name}, adset=${adsetId}` });

      const creativeRes = await fetch(`https://graph.facebook.com/v21.0/${ad_account_id}/adcreatives`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(creativePayload),
      });
      const creativeData = await creativeRes.json();

      if (creativeData.error) {
        const errDetail = `${creativeData.error.message} | code=${creativeData.error.code} | subcode=${creativeData.error.error_subcode} | user_title=${creativeData.error.error_user_title || ""} | user_msg=${creativeData.error.error_user_msg || ""}`;
        logs.push({ step: `creative_${idx}`, status: "error", ts: ts(), detail: `${errDetail} | payload=${JSON.stringify(sanitizePayload(creativePayload))}` });
        failures.push({ index: idx, name: cr.name, step: "creative", reason: errDetail });
        return false;
      }

      creativesCreated++;
      logs.push({ step: `creative_${idx}`, status: "success", ts: ts(), detail: `id=${creativeData.id}` });

      const adPayload: Record<string, any> = {
        name: cr.name,
        adset_id: adsetId,
        creative: { creative_id: creativeData.id },
        status: "ACTIVE",
        access_token,
      };
      logs.push({ step: `ad_${idx}`, status: "start", ts: ts(), detail: `name=${cr.name}, creative_id=${creativeData.id}` });

      const adRes = await fetch(`https://graph.facebook.com/v21.0/${ad_account_id}/ads`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(adPayload),
      });
      const adData = await adRes.json();
      if (adData.error) {
        const errDetail = `${adData.error.message} | code=${adData.error.code} | subcode=${adData.error.error_subcode}`;
        logs.push({ step: `ad_${idx}`, status: "error", ts: ts(), detail: errDetail });
        failures.push({ index: idx, name: cr.name, step: "ad", reason: errDetail });
        return false;
      }
      adIds.push(adData.id);
      adsCreated++;
      logs.push({ step: `ad_${idx}`, status: "success", ts: ts(), detail: `id=${adData.id}` });
      return true;
    };

    // ── Standard adset creation (used by ALL presets now) ──
    const createAdset = async (adsetPayload: Record<string, any>, stepLabel: string): Promise<{ id?: string; error?: any }> => {
      logs.push({ step: stepLabel, status: "start", ts: ts(), detail: `name=${adsetPayload.name} | payload=${JSON.stringify(sanitizePayload(adsetPayload))}` });

      const res = await fetch(`https://graph.facebook.com/v21.0/${ad_account_id}/adsets`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(adsetPayload),
      });
      const data = await res.json();
      console.log(`[publish] adset response (${stepLabel}): ${JSON.stringify(data)}`);

      if (data.error) {
        const err = data.error;
        const errDetail = `${err.message} | code=${err.code} | subcode=${err.error_subcode} | user_title=${err.error_user_title || ""} | user_msg=${err.error_user_msg || ""}`;
        logs.push({ step: stepLabel, status: "error", ts: ts(), detail: errDetail });
        return { error: err };
      }
      logs.push({ step: stepLabel, status: "success", ts: ts(), detail: `id=${data.id}` });
      return { id: data.id };
    };

    if (structure === "CBO") {
      const adsetPayloadName = adset_name || `${generated_name || "Campaign"} - AdSet`;
      const adsetPayload = buildAdsetPayload(adsetPayloadName);
      const adsetResult = await createAdset(adsetPayload, "adset");

      if (adsetResult.error) {
        return respond({ ok: false, step: "adset", campaign_id: campaignId, ...formatMetaError(adsetResult.error) });
      }
      const adsetId = adsetResult.id!;
      adsetIds.push(adsetId);
      adsetsCreated = 1;

      for (let i = 0; i < resolvedCreatives.length; i++) {
        await createCreativeAndAd(resolvedCreatives[i], i + 1, adsetId);
      }
    } else {
      // ABO: N AdSets, 1 Ad each
      for (let i = 0; i < resolvedCreatives.length; i++) {
        const cr = resolvedCreatives[i];
        const idx = i + 1;
        const adsetNum = String(idx).padStart(2, "0");
        const baseAdsetName = adset_name || `${generated_name || "Campaign"} - AdSet`;
        const adsetPayloadName = resolvedCreatives.length > 1 ? `${baseAdsetName} ${adsetNum}` : baseAdsetName;

        const adsetPayload = buildAdsetPayload(adsetPayloadName);
        const adsetResult = await createAdset(adsetPayload, `adset_${idx}`);

        if (adsetResult.error) {
          failures.push({ index: idx, name: cr.name, step: "adset", reason: adsetResult.error.message });
          continue;
        }
        const adsetId = adsetResult.id!;
        adsetIds.push(adsetId);
        adsetsCreated++;

        await createCreativeAndAd(cr, idx, adsetId);
      }
    }

    // ── Summary ──
    logs.push({ step: "summary", status: adsCreated > 0 ? "success" : "error", ts: ts(), detail: `preset=${presetLabel}, structure=${structure}, adsets=${adsetsCreated}, creatives=${creativesCreated}, ads=${adsCreated}, failures=${failures.length}` });
    if (failures.length > 0) {
      logs.push({ step: "failure_details", status: "error", ts: ts(), detail: failures.map(f => `#${f.index} "${f.name}" failed at ${f.step}: ${f.reason}`).join(" | ") });
    }

    if (adsCreated === 0) {
      return respond({
        ok: false, step: "publish", campaign_id: campaignId,
        error_message: `Nenhum anúncio criado. ${adsetsCreated} adset(s), ${creativesCreated} creative(s). Verifique os logs.`,
        adsets_created: adsetsCreated, ads_created: 0, failures,
      });
    }

    return respond({
      ok: true, campaign_id: campaignId,
      adset_id: adsetIds[0], adsets_created: adsetsCreated,
      creatives_created: creativesCreated, ads_created: adsCreated,
      ad_id: adIds[0], adset_ids: adsetIds, ad_ids: adIds,
      failures: failures.length > 0 ? failures : undefined,
    });
  } catch (e) {
    console.error("[publish] unhandled error", e);
    const stackTrace = e.stack ? e.stack.split("\n").slice(0, 5).join(" | ") : "";
    logs.push({ step: "edge_function_internal", status: "error", ts: ts(), detail: `${e.message} | stack: ${stackTrace}` });
    return respond({
      ok: false,
      step: "edge_function_internal",
      error_message: e.message,
      stack_trace: stackTrace,
      preset_used: isWhatsAppPreset ? "FASE 3" : isIgProfilePreset ? "FASE 1" : "GENERIC",
      structure: structure,
    });
  }
});
